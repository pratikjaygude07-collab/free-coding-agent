# Taskboard

A small task manager library: tasks with priorities, due dates and tags,
JSON saving/loading, and a few text helpers.

Run the tests (from this folder):

    pytest -q
