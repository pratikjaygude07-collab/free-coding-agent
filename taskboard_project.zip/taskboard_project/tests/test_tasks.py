from datetime import date

import pytest

from taskboard.tasks import TaskBoard

TODAY = date(2026, 11, 8)


def test_add_returns_task_with_defaults():
    board = TaskBoard()
    task = board.add("Write report")
    assert task.title == "Write report"
    assert task.priority == 2
    assert task.done is False
    assert task.tags == []


@pytest.mark.parametrize("bad", [0, 4, -1])
def test_add_rejects_bad_priority(bad):
    with pytest.raises(ValueError):
        TaskBoard().add("x", priority=bad)


def test_ids_stay_unique_after_removal():
    board = TaskBoard()
    a = board.add("A")
    b = board.add("B")
    board.remove(a.id)
    c = board.add("C")
    assert c.id != b.id
    assert board.get(b.id).title == "B"


def test_get_unknown_id_raises_keyerror():
    with pytest.raises(KeyError):
        TaskBoard().get(99)


def test_complete_marks_task_done():
    board = TaskBoard()
    t = board.add("A")
    board.complete(t.id)
    assert board.get(t.id).done is True


def test_filter_by_tag_ignores_case():
    board = TaskBoard()
    board.add("A", tags=["Work"])
    board.add("B", tags=["home"])
    assert [t.title for t in board.filter_by_tag("work")] == ["A"]
    assert [t.title for t in board.filter_by_tag("HOME")] == ["B"]


def test_filter_by_tag_no_match():
    board = TaskBoard()
    board.add("A", tags=["work"])
    assert board.filter_by_tag("gym") == []


def test_overdue_includes_past_due():
    board = TaskBoard()
    board.add("late", due=date(2026, 11, 1))
    assert [t.title for t in board.overdue(TODAY)] == ["late"]


def test_overdue_excludes_due_today_and_future():
    board = TaskBoard()
    board.add("today", due=TODAY)
    board.add("later", due=date(2026, 12, 1))
    board.add("no date")
    assert board.overdue(TODAY) == []


def test_overdue_excludes_finished_tasks():
    board = TaskBoard()
    t = board.add("late but done", due=date(2026, 11, 1))
    board.complete(t.id)
    assert board.overdue(TODAY) == []


def test_sorted_by_priority_high_first():
    board = TaskBoard()
    board.add("low", priority=1)
    board.add("high", priority=3)
    board.add("mid", priority=2)
    assert [t.title for t in board.sorted_by_priority()] == ["high", "mid", "low"]


def test_sorted_ties_by_due_date_then_title():
    board = TaskBoard()
    board.add("zeta", priority=3, due=date(2026, 12, 1))
    board.add("alpha", priority=3, due=date(2026, 12, 1))
    board.add("soon", priority=3, due=date(2026, 11, 20))
    board.add("undated", priority=3)
    order = [t.title for t in board.sorted_by_priority()]
    assert order == ["soon", "alpha", "zeta", "undated"]


def test_summary_counts_and_percent():
    board = TaskBoard()
    a = board.add("A")
    board.add("B")
    board.add("C")
    board.complete(a.id)
    assert board.summary() == {"total": 3, "done": 1, "percent_done": 33}


def test_summary_of_empty_board():
    assert TaskBoard().summary() == {"total": 0, "done": 0, "percent_done": 0}
