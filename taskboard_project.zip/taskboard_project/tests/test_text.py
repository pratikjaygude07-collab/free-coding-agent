from taskboard.text import format_minutes, slugify, truncate


def test_truncate_short_text_unchanged():
    assert truncate("hello", 10) == "hello"


def test_truncate_exact_length_unchanged():
    assert truncate("hello", 5) == "hello"


def test_truncate_long_text_fits_max_length():
    result = truncate("The quick brown fox", 10)
    assert result == "The qui..."
    assert len(result) == 10


def test_slugify_simple():
    assert slugify("Hello World") == "hello-world"


def test_slugify_punctuation_and_spaces():
    assert slugify("  Hello,  World! ") == "hello-world"


def test_slugify_collapses_repeated_separators():
    assert slugify("Plan: Q4 -- Review") == "plan-q4-review"


def test_format_minutes_under_an_hour():
    assert format_minutes(45) == "45m"
    assert format_minutes(0) == "0m"


def test_format_minutes_hours_and_minutes():
    assert format_minutes(90) == "1h 30m"


def test_format_minutes_whole_hours():
    assert format_minutes(120) == "2h"
