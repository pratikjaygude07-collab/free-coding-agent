from datetime import date

from taskboard.storage import load, save
from taskboard.tasks import TaskBoard


def test_roundtrip_keeps_fields(tmp_path):
    board = TaskBoard()
    board.add("Pay rent", priority=3, due=date(2026, 12, 1), tags=["home", "money"])
    path = tmp_path / "board.json"
    save(board, path)
    loaded = load(path)
    t = loaded.tasks[0]
    assert (t.title, t.priority, t.due, t.tags) == ("Pay rent", 3, date(2026, 12, 1), ["home", "money"])


def test_roundtrip_keeps_done_flag(tmp_path):
    board = TaskBoard()
    t = board.add("Done task")
    board.complete(t.id)
    path = tmp_path / "board.json"
    save(board, path)
    assert load(path).tasks[0].done is True


def test_load_missing_file_gives_empty_board(tmp_path):
    board = load(tmp_path / "does_not_exist.json")
    assert board.tasks == []
