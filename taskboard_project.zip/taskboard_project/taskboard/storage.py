"""Saving and loading a TaskBoard as a JSON file."""
import json
from datetime import date
from pathlib import Path

from taskboard.tasks import Task, TaskBoard


def task_to_dict(task):
    return {
        "id": task.id,
        "title": task.title,
        "priority": task.priority,
        "due": task.due.isoformat() if task.due else None,
        "tags": task.tags,
        "done": task.done,
    }


def task_from_dict(data):
    return Task(
        id=data["id"],
        title=data["title"],
        priority=data["priority"],
        due=date.fromisoformat(data["due"]) if data["due"] else None,
        tags=data["tags"],
    )


def save(board, path):
    """Write the board to a JSON file."""
    items = [task_to_dict(t) for t in board.tasks]
    Path(path).write_text(json.dumps(items, indent=2), encoding="utf-8")


def load(path):
    """Read a board from a JSON file. If the file does not exist, return an empty board."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    board = TaskBoard()
    board.tasks = [task_from_dict(d) for d in data]
    return board
