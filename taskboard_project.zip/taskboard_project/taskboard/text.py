"""Small text helpers."""


def truncate(text, max_length):
    """Shorten text to at most max_length characters in total.
    If it had to be cut, the result ends with '...' (which counts toward max_length)."""
    if len(text) <= max_length:
        return text
    return text[:max_length] + "..."


def slugify(text):
    """Lowercase the text and replace every run of characters that are not
    letters or digits with a single hyphen. No hyphen at the start or end.
    Example: '  Hello,  World! ' -> 'hello-world'"""
    return text.lower().replace(" ", "-")


def format_minutes(minutes):
    """45 -> '45m', 90 -> '1h 30m', 120 -> '2h', 0 -> '0m'."""
    hours, mins = divmod(minutes, 60)
    if hours == 0:
        return f"{mins}m"
    return f"{hours}h {mins}m"
