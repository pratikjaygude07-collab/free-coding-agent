"""Task management logic."""
from dataclasses import dataclass, field
from datetime import date


@dataclass
class Task:
    id: int
    title: str
    priority: int = 2          # 1 = low, 2 = medium, 3 = high
    due: date = None
    tags: list = field(default_factory=list)
    done: bool = False


class TaskBoard:
    def __init__(self):
        self.tasks = []

    def add(self, title, priority=2, due=None, tags=None):
        """Add a task and return it. Priority must be 1, 2 or 3 (else ValueError).
        Every task gets an id that has never been used by another task on this board."""
        task = Task(id=len(self.tasks) + 1, title=title, priority=priority,
                    due=due, tags=list(tags or []))
        self.tasks.append(task)
        return task

    def get(self, task_id):
        """Return the task with this id, or raise KeyError."""
        for t in self.tasks:
            if t.id == task_id:
                return t
        raise KeyError(task_id)

    def remove(self, task_id):
        self.tasks.remove(self.get(task_id))

    def complete(self, task_id):
        self.get(task_id).done = True

    def filter_by_tag(self, tag):
        """All tasks having this tag. Upper/lower case does not matter."""
        return [t for t in self.tasks if tag in t.tags]

    def overdue(self, today):
        """Unfinished tasks whose due date is before `today`.
        A task due today is not overdue yet."""
        return [t for t in self.tasks if t.due is not None and t.due <= today]

    def sorted_by_priority(self):
        """Highest priority first. Ties: earlier due date first (tasks with no
        due date last), then alphabetical by title."""
        return sorted(self.tasks, key=lambda t: t.priority)

    def summary(self):
        """Counts as a dict: total, done, percent_done (0 when the board is empty)."""
        total = len(self.tasks)
        done = sum(1 for t in self.tasks if t.done)
        percent = round(done / total * 100)
        return {"total": total, "done": done, "percent_done": percent}
